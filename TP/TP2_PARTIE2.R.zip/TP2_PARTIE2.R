#TP2_Partie2
#Loi forte des grands nombres
M=2000
X = runif(M,0,1) #cree M variable aleatoire uniforme
S = cumsum(X) #cree vecteur des sommes succesif 
N = seq(1,M, by=1) #des valeur entre 1 et M le pas c'est un 
plot(N, S/N) #dessin de Sn/N en fonction de N 
abline(h=0.5, col="red") #ligne horizontale d'ordre E[X 1].
#on peut dire que quand N est grand Sn/N tende vers meu et cest LDGN 
#le graphe a chaque fois qu'on compile le code par ce que on produit des nouvelle variable aleatoirre defirantes des pricidente 

#Illustrations pour d’autres lois
funif <- function(a,b,N){
  X = runif(N,a,b)
  S = cumsum(X)
  n = seq(1,N, by=1)
  plot(n, S/n)
  abline(h=(a+b)/2, col="red")
}
funif(2,5,2000)

fexp <- function(a,N){
  X = rexp(N,a)#rexp genere N variable aléatoire de loi exponentielle de paramètre alpha = a dans notre cas
  S = cumsum(X)
  n = seq(1,N, by=1)
  plot(n, S/n)
  abline(h=1/a, col="red")
}
fexp(10,10000)
#le graphe a chaque fois qu'on compile le code par ce que on produit des nouvelle variable aleatoirre defirantes des pricidente 
#donc on peut dire que pour la somme des variable aleatoire de meme lois et de meme parametre quand N est grand est grand la lois tend vers mue


fcauchy <- function(N){
  X = rcauchy(N)
  S = cumsum(X)
  n = seq(1,N, by=1)
  plot(n, S/n)
       
}
fcauchy(1000)
# a chque fois qu'on rexecute le code on a des points differents 
# on a à chaque fois un graphique different ce qui explique l'absence de l'esperance

#Prtie 3 
#Theoreme de la limite centrale (TLC)
#Illustration pour la loi uniforme sur [0,1]
N= 100
M = 10000
m = matrix(runif(N*M,0,1), N, M) # matrice N ligne M colone de V A uniforme sur [0,1]
s = rowSums(m/N)# la moyenne de niem ellement 
hist(s) # DESSIN DE resultat
mu=0.5
sigma=(sqrt(1/12))/(sqrt(N))
curve(dnorm(x,mu,sigma),add=TRUE,col = "red", lwd = 2)
#curve(dnorm(x,mean=5500,sd=1000),add=TRUE,col='blue')

#Illustrations pour d’autres lois





#4 Etudier la formule du transfert (a ne pas faire)

#il reste 
#5 Un autre exemple de convergence
#6 Un autre exemple de loi limite






